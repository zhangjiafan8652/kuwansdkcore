package com.ceshi.demo;

import com.yayawan.impl.YYApplication;
import com.yayawan.main.YaYaWan;

public class GameApplication extends YYApplication{


	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	
	}

}

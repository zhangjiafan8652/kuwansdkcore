/** Automatically generated file. DO NOT MODIFY */
package com.tencent.tmgp.yjxysml;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}